# Changelog

## 0.1.0

- Initialize repository.
- Define SQL statements.
- Add AWS connection.
- Add ETL methods.
- Analyze data.
